const categories = [
  "Books",
  "Toys",
  "Furniture",
  "Fitness",
  "Home",
  "Kids",
  "Appliances",
  "Decor",
  "Clothing",
  "Electronics",
  "Garden",
  "Art Supplies",
  "Storage",
  "Tools",
];

export default categories;
